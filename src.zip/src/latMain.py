import os
import urllib
import sys

from google.appengine.api import users
from google.appengine.ext import ndb

import jinja2
import webapp2
import json
import random
import string

JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
    extensions=['jinja2.ext.autoescape'])

def randomKey(N=15):
  return ''.join(random.choice(string.ascii_uppercase + string.digits + string.ascii_lowercase) for x in range(N))


class Location(ndb.Model):
    timestampMs = ndb.IntegerProperty()
    latitudeE7 = ndb.IntegerProperty()
    longitudeE7 = ndb.IntegerProperty()
    accuracy = ndb.IntegerProperty()
    velocity = ndb.IntegerProperty()
    heading = ndb.IntegerProperty()
    altitude = ndb.IntegerProperty()
    verticalAccuracy = ndb.IntegerProperty()

class Users(ndb.Model):
    userid = ndb.StringProperty()
    owner = ndb.BooleanProperty()

class Keys(ndb.Model):
    keyid = ndb.StringProperty()  

class MainPage(webapp2.RequestHandler):
  def get(self):
    user = users.get_current_user()
    if user:
      userCheck = Users.get_by_id(user.user_id())
      if userCheck:
        locations = Location.query().order(-Location.timestampMs).fetch(10)
        template = JINJA_ENVIRONMENT.get_template('index.html')
        template_values = {'locations': locations, 'userName': user.nickname()}
        self.response.write(template.render(template_values))
      else:
        greeting = ('Sorry, %s you do not have access! (<a href="%s">sign out</a>)' %
                        (user.nickname(), users.create_logout_url('/')))
        self.response.write("<html><body>%s</body></html>" % greeting )
    else:
      greeting = ('<a href="%s">Please Sign in</a>.' %
                        users.create_login_url('/'))
      self.response.write("<html><body>%s</body></html>" % greeting) 

class setupOwner(webapp2.RequestHandler):
  def get(self):
    numberOfUsers = Users.query().count()
    if numberOfUsers > 0:
      self.response.write("<html><body>Already setup</body></html>") 
      return
    user = users.get_current_user()
    if user:
      adminUser = Users(id=user.user_id())
      adminUser.userid = user.user_id()
      adminUser.owner = True
      adminUser.put()
      key = randomKey(15)
      newKey = Keys(id=key)
      newKey.keyid = key
      newKey.put()
      greeting = ('All setup, %s you have access!' % user.nickname())
      greeting += '<br/> Your key is: %s' % key
      self.response.write("<html><body>%s</body></html>" % greeting)
    else:
      greeting = ('<a href="%s">Please Sign in</a>.' %
                        users.create_login_url('/'))
      self.response.write("<html><body>%s</body></html>" % greeting)
        
class insertLocation(webapp2.RequestHandler):
  def get(self):
    self.response.write("hello Word")
  def post(self):
    self.response.headers['Content-Type'] = 'application/json'
    try:
      key = self.request.GET['key']
    except KeyError:
      key = None
    if not Keys.get_by_id(key):
      self.abort(403)
    postBody = json.loads(self.request.body)   
    newLocation = Location.get_by_id(postBody['timestampMs'])
    if newLocation:
      self.response.out.write("Time stamp error")
      self.abort(200)
    try:
      newLocation = Location(id=postBody['timestampMs'])
      newLocation.timestampMs = int(postBody['timestampMs'])
      newLocation.latitudeE7 = int(postBody['latitudeE7'])
      newLocation.longitudeE7 = int(postBody['longitudeE7'])
      newLocation.accuracy = int(postBody['accuracy'])
      newLocation.velocity = int(postBody['velocity'])
      newLocation.heading = int(postBody['heading'])
      newLocation.altitude = int(postBody['altitude'])
      newLocation.verticalAccuracy = int(postBody['verticalAccuracy'])
      newLocation.put()
    except:
      self.response.out.write("Unexpected error")
      self.abort(400)
      
    response = {'data': newLocation.to_dict()}
    self.response.set_status(200)
    self.response.out.write(json.dumps(response))


class insertBack(webapp2.RequestHandler):
  def post(self):
    try:
      key = self.request.POST['key']
      if not Keys.get_by_id(key):
        self.abort(403)
      latitude = int(float(self.request.POST['latitude']) * 1E7)
      longitude = int(float(self.request.POST['longitude']) * 1E7)
      accuracy = int(float(self.request.POST['accuracy']))
      speed = int(float(self.request.POST['speed']))
      altitude = int(float(self.request.POST['altitude']))
      timestamp = int(self.request.POST['timestamp'])
      timezone = self.request.POST['timezone']
    except KeyError:
      self.response.out.write("Unexpected error")
      self.abort(400)
      
    newLocation = Location.get_by_id(id=str(timestamp))
    if newLocation:
      self.response.out.write("Time stamp error")
      self.response.set_status(200)
    try:
      newLocation = Location(id=str(timestamp))
      newLocation.timestampMs = timestamp
      newLocation.latitudeE7 = latitude
      newLocation.longitudeE7 = longitude
      newLocation.accuracy = accuracy
      newLocation.velocity = speed
      newLocation.heading = 0
      newLocation.altitude = altitude
      newLocation.verticalAccuracy = 0
      newLocation.put()
    except:
      self.response.out.write("Unexpected error")
      self.abort(400)
      
    response = {'data': newLocation.to_dict()}
    self.response.set_status(200)
    self.response.out.write(json.dumps(response))

application = webapp2.WSGIApplication([('/', MainPage),('/insert',insertLocation),('/backitude',insertBack),('/setup',setupOwner)], debug=True)

     